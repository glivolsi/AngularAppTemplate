import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'demo',
    template: `demo works!`
})

export class DemoComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}