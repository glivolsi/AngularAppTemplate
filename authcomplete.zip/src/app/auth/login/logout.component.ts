import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'logout',
    template: `logout work`
})

export class LogoutComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}