export interface User {
    UserName: string,
    LoginName: string
}